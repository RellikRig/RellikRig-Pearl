Third-party notices: RellikRig native proof utilities

This directory accompanies the Pearl/NOCK proof utilities. See
DEPENDENCY-NOTICES.json for the originating projects, versions and scope.
The Rust inventory follows the retained build dependency records and may
include conservative notice entries for build-only inputs. It does not
claim to be an inventory of RellikRig's separate mining engines.

The vendored Pearl zk-pow, layout-macro and pearl-blake3 components use the
Pearl license. Vendored Plonky2, Field, Maybe Rayon, Util and Starky have
component notices preserved, including both MIT and Apache alternatives.
The recorded vendored source snapshot retained one older upstream Starky
file. These third-party licenses cover their respective components; they
do not make the RellikRig application source available.
